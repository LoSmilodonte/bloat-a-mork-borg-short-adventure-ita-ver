# bloat-a-mork-borg-short-adventure-ita-ver
 Modulo avventura versione ITALIANA dell'avventura BLOAT da utilizzare su Foundry VTT
 <br> utilizza questo link per installare il contenuto direttamente in Foundry --> https://github.com/LoSmilodonte/bloat-a-mork-borg-short-adventure-ita-ver/releases/download/1.0.1/world.json <br>
 Bloat è un'avventura per Mork Borg creata da Johan Nohr e Greg Saunders
 <br>
 tutti i diritti sono dei rispettivi autori
 <br>
 Mi sono limitato a creare le scene di gioco su FoundryVTT
<br>
pdf liberamente disponibile su https://morkborg.exlibrisrpg.com/entries/bloat
<br>
Bloat <br>
Johan Nohr <br>
Greg Saunders <br>
Concept: “The Gourmand’s Cutlery allows the wielder to eat anything. Which is good, as the user becomes famished and must eat.” <br>
Content: A wonderland of overconsumption and excrescence <br>
Writing: Contributes greatly to dungeon’s character <br>
Art/design: Just offal <br>
Usability: Layout facilitate easy navigation

